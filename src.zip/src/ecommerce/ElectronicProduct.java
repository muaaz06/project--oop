package ecommerce;
public class ElectronicProduct extends Product{
   
    private String brand;
    private int warrantyPeriod;

    public ElectronicProduct(String brand, int warrantyPeriod, int productId, String name, double price) {
        super(productId, name, price);
        if (warrantyPeriod < 0) warrantyPeriod = Math.abs(warrantyPeriod);
        this.brand = brand;
        this.warrantyPeriod = warrantyPeriod;
    }
    
    

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public int getWarrantyPeriod() {
        return warrantyPeriod;
    }

    public void setWarrantyPeriod(int warrantyPeriod) {
        if (warrantyPeriod < 0) warrantyPeriod = Math.abs(warrantyPeriod);
        this.warrantyPeriod = warrantyPeriod;
    }
    
    
}
