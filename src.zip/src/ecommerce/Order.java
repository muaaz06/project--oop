package ecommerce;

public class Order {
    
    private int customerId;
    private int orderId;
    private Product[] products;
    private double totalPrice;

    public Order(int customerId, int orderId, Product[] products, double totalPrice) {
        if (customerId < 0) customerId = Math.abs(customerId);
        if (orderId < 0) orderId = Math.abs(orderId);
        if (totalPrice < 0) totalPrice = Math.abs(totalPrice);
        this.customerId = customerId;
        this.orderId = orderId;
        this.products = products;
        this.totalPrice = totalPrice;
    }
    
    
    public void printOrderInfo() {
        System.out.println("");
        System.out.println("Customer id : " + this.customerId);
        System.out.println("order id : " + this.orderId);
        System.out.println("products : ");
        for (int i = 0; i < products.length; i++) {
            System.out.println((i + 1) + ")" + this.products[i]);
        }
        System.out.println("total price : " + this.totalPrice);
    }

}
