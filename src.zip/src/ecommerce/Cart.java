package ecommerce;

public class Cart {
    private int customerId;
    private int nProduct;
    private Product[] products;

    public Cart(int customerId, int nProduct) {
        if (customerId < 0) customerId = Math.abs(customerId);
        if (nProduct < 0) nProduct = Math.abs(nProduct);
        this.customerId = customerId;
        this.nProduct = nProduct;
        this.products = new Product[nProduct];
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        if (customerId < 0) customerId = Math.abs(customerId);
        this.customerId = customerId;
    }

    public int getnProduct() {
        return nProduct;
    }

    public void setnProduct(int nProduct) {
        if (nProduct < 0) nProduct = Math.abs(nProduct);
        this.nProduct = nProduct;
    }

    public Product[] getProducts() {
        return products;
    }

    public void setProducts(Product[] products) {
        this.products = products;
    }
    
    
    
    // functions 
    public void addProduct(Product product) {  
        for (int i = 0; i < this.products.length; i++) 
            if (this.products[i] == null) {
                this.products[i] = product;
                return;
            }
    }
    
    public void removeProduct(int productId) {
        if (this.products[this.nProduct - 1] != null) this.products[this.nProduct - 1] = null;
        for (int i = 0; i < this.products.length; i++) {
            if (this.products[i] != null && this.products[i].getProductId() == productId) {
                this.products[i] = null;
                return;
            }
        }
    }
    
    public double calculatePrice() {
        double total = 0;
        for (int i = 0; i < this.products.length; i++) {
            if (this.products[i] != null) total += this.products[i].getPrice();
        }
        return total;
    }
    
    public Order placeOrder() {
        return new Order(this.customerId, 1, this.products, this.calculatePrice());
    }
}
