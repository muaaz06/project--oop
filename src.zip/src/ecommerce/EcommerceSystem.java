package ecommerce;

import java.util.Scanner;

public class EcommerceSystem {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        ElectronicProduct elotronic = new ElectronicProduct("smartphone", 1, 1, "Samsung", 599.9);
        ClothingProduct cloth = new ClothingProduct("Medium", "Cotton" , 2, "T-shirt", 19.99);
        BookProduct book = new BookProduct("O'Rilly ", "X Publications", 3, "OOP", 39.99);
        
        System.out.println("Welcome to the E-Commerce System!");
        System.out.println("Please enter your id: ");
        
        int id = sc.nextInt();
        System.out.println("please enter your name : ");
        String name = sc.next();
        System.out.println("please enter your adress : ");
        String adress = sc.nextLine();
        sc.nextLine();
        
        Customer customer = new Customer(id, name, adress);
        
        System.out.print("Enter number of products : ");
        int productNumber = sc.nextInt();
        
        Cart cart = new Cart(customer.getCustomerId(), productNumber);
        boolean running = true ;
        while (running) {
            System.out.println("Add (a) or Remove (r) or Place order (p) or exit (e) : ");
            char choice = sc.next().toLowerCase().charAt(0);
            switch (choice) {
                case 'a' -> {
                    System.out.println("Enter product id : ");
                    System.out.println("1: add electronic \n 2: cloth \n 3: book ");
                    int proId = sc.nextInt();
                    switch (proId) {
                        case 1 -> {
                            cart.addProduct(elotronic);
                    }
                        case 2 -> {
                            cart.addProduct(cloth);
                    }
                        case 3 -> {
                            cart.addProduct(book);
                    }
                        default -> System.out.println("we have only 1 - 3 product");
                    }
                }
                case 'r' -> {
                    System.out.println("Enter product id : ");
                    int proId = sc.nextInt();
                    cart.removeProduct(id);
                }
                
                case 'p' -> {
                    cart.placeOrder().printOrderInfo();
                }
                case 'e' -> {
                    running = false ;
                }
                default -> System.out.println("Enter only a, r , p or e ");
            }
        }
    }
}
