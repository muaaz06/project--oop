package ecommerce;

public class Product {
    private int productId;
    private String name;
    private double price;

    public Product(int productId, String name, double price) {
        if (productId < 0) productId = Math.abs(productId);
        if (price < 0) price = Math.abs(price);
        this.productId = productId;
        this.name = name;
        this.price = price;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        if (productId < 0) productId = Math.abs(productId);
        this.productId = productId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        if (price < 0) price = Math.abs(price);
        this.price = price;
    }

    @Override
    public String toString() {
        return "product id : " + this.productId + "\tproduct name :" + this.name + "\tproduct price : " + this.price;
    }
    
}


